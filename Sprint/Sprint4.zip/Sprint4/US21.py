'''
    Sawyer Coleman
    US21 Function File
    SSW_555_Agile_Methods
    BHS_Project_SSW_555
    Sprint 4
'''

NA = "N/A"

def US21(WIFE_Sex = NA, HUSB_Sex = NA):
    if (WIFE_Sex == "F" and HUSB_Sex == "M"):
        return True
    elif WIFE_Sex != "F":
        return "Wife"
    elif HUSB_Sex != "M":
    	return "Husband"