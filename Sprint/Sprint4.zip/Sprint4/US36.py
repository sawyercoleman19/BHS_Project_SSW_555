'''
    Bharath Kumar
    US36 Functions File
    SSW_555_Agile_Methods
    BHS_Project_SSW_555
    Sprint 3
    '''

import US35

def US36(DeathDic):
	return US35.US35(DeathDic)