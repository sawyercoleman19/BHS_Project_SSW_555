'''
    Bharath Kumar
    US36 Functions File
    SSW_555_Agile_Methods
    BHS_Project_SSW_555
    Sprint 3
    '''

import US38

def US39(MarrDic):
	return US38.US38(MarrDic)